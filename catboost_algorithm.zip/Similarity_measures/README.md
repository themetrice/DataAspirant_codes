### SIMILARITY MEASURES

[Post link](http://dataaspirant.com/2015/04/11/five-most-popular-similarity-measures-implementation-in-python/)