#K-Nearest Neighbor implementation in R using caret package

Implement KNN algorithm to recognize the origin of wine. 
Read the whole article [here](https://dataaspirant.com/2017/01/09/knn-implementation-r-using-caret-package/)

![alt tag](http://dataaspirant.com/wp-content/uploads/2017/01/Knn-implementation-R-caret-1.jpg)
